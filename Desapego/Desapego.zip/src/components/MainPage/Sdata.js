const Sdata = [
  {
    id: 1,
    title: "50% de desconto na sua primeira compra",
    desc: "Aproveite esse mega desconto.",
    cover: "./images/SlideCard/slide-1.png",
  },
  {
    id: 2,
    title: "50% de desconto na sua primeira compra",
    desc: "Aproveite esse mega desconto.",
    cover: "./images/SlideCard/slide-2.png",
  },
  {
    id: 3,
    title: "50% de desconto na sua primeira compra",
    desc: "Aproveite esse mega desconto.",
    cover: "./images/SlideCard/slide-3.png",
  },
  {
    id: 4,
    title: "50% de desconto na sua primeira compra",
    desc: "Aproveite esse mega desconto.",
    cover: "./images/SlideCard/slide-4.png",
  },
]
export default Sdata
